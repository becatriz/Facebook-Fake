<?php
/*      PLATFORM NAME                         */
$PLATFORM['NAME'] = 'BREEZE_ULTIMATE_SOCIAL_NETWORK' ;

/*      PLATFORM VERSION                      */
$PLATFORM['VERSION'] = '2.4' ; 

/*      PLATFORM VERSION FOR EXTENSIONS       */
$PLATFORM['VERSION_EXT'] = '2.0' ; 

/*      PLATFORM LANGUAGE CODEs               */
$PLATFORM['OLD_LANG_VERSION_CODES'] = '2.4'; 

?>