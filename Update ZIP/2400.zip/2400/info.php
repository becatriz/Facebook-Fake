<?php 

$up_name = $up_version = '2.4.0.0';

$up_description = 'Change log <p>
<li>Added Website Template Processor(WTP)</li>
<li>WTP: Theme assets now include 99% of entire website HTML code</li>
<li>WTP: Classes code size is now 383KB (Before 432KB)</li>
<li>WTP: Website design is now 99% based on theme</li>
<li>WTP: Website design is highly customisable</li>
<li>Added public access to user profiles(Non-registered users can access profiles)</li>
<li>Added new query preset system for settings and registration</li>
<li>Added new registration method</li>
<li>Added new group feeds generator method</li>
<li>Added new page feeds generator method</li>
<li>Added new navigation for page categories in admin panel</li>
<li>Added photos option that show user gallery from side navigation</li>
<li>Added AM/PM time stamps for group and page logs</li>
<li>Added ability to show mix feeds from pages, groups and users on home(Will work after friends)</li>
<li>Added last year filter to trending section</li>
<li>Re-worked on add members to group</li>
<li>Re-worked on add chat members to chat group</li>
<li>Re-worked on widget notifications system</li>
<li>Re-worked on notifications center (2+ Bug fixes)</li>
<li>Re-worked on pages search</li>
<li>Re-worked on groups search</li>
<li>Re-worked on videos search</li>
<li>Re-worked on members search</li>
<li>Re-worked on group member request system</li>
<li>Re-worked on profile about generating system</li>
<li>Re-designed new about page for profile</li>
<li>Removed over colapsing of user name in notifications</li>
<li>Improved 10+ basic functions of main class</li>
<li>Re-worked on language and terms container</li>
<li>Fixed profile,group and page cover loading speed</li>
<li>Fixed bugs related with page invite system</li>
<li>Fixed issue related with all-time filter on trending feeds</li>
<li>Fixed 20+ code comments</li>
<li>Fixed titles in side navigation</li>
<li>Fixed issues related with registration(Infinite loading on some servers)</li>
<li>Fixed bug while adding member to group from suggestions</li>
<li>Fixed JS param issue on page loading</li>
<li>Fixed admin panel log out bug(Rare cases)</li>
<li>Fixed 5+ minor issues in designs</li>
</p>';


?>