<?php 
$update_sqls = '';
?>