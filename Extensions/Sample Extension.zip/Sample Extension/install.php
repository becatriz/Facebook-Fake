<?php 

// Files to extend (CASE SENSTIVE)
/* Extension installer will go through each file defined in this array 
   and do str_replace If you want multiple replacements in a file, add
   file location and Define multiple matches as an array in arrays 
   $extend_strings and $extended_strings on corresponding key.
 */
$extend_files = array( 

                        // File 1
						'./themes/Standards/html/home/home'.$TEXT['templates_extension'],
						
				    );

// Match Strings to extend (CASE SENSTIVE)
/* Extension installer will go through each file and find the strings or paragraphs defined in this array 
   If you want to replace single paragraph or line then use 'your line or paragraph'
   If you want to replace two or more paragraphs then use array(para1,para2,..).
   
   CAUTION
   Because str_replace() replaces left to right, it might replace a previously inserted 
   value when doing multiple replacements.
   
*/
$extend_strings = array(
                        
						
						// Array of lines to find in File 1
						array(
							'<span class="brz-small">&copy;</span> {$TEXT->web_name} {$TEXT->_uni-All_rights_reserved}',
							'{$TEXT->_uni-Language} : {$TEXT->TEMP-active_lang}',
							),
						

				    );
			
// New strings 
/* Extension installer will go through each file and find the strings or paragraphs based on 
   arrays $extend_strings and $extended_strings.If found matches installer will replace the matches
   with corresponding keys defined in this array.
*/
$extended_strings = array(

						// Array of lines to replace in File 1 
						array(
							'<span class="brz-small">&copy;</span> {$TEXT->web_name} {$TEXT->_uni-All_rights_reserved} : Support Extensions',
							'{$TEXT->_uni-Language} : {$TEXT->TEMP-active_lang} : Support extensions',
							),

				
				    );
					
// Log (Optional)
/* Here are the log notes you can set to display to admin while updating files
   each time when installer switch file it will look for the coresponding 
   log note in this array, if found will be displayed to admin else skip.
*/
$extention_key_notes = array(

                        // Show in log while updating File 1
                        'Updating footer file  ->  Footer',
						
				    );					
			

?>