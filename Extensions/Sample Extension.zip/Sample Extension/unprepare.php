<?php 

/* This file will be executed before extension Un-installation
   You can do DATABSE related changes in this file
 */
 
?>