<?php 

// Info file

// Extension name  
// NOTE ::: Important Name of the extension, name of the ZIP file, name of the folder inside the ZIP, all must be same and unique
$ext_name = 'Sample Extension';

// Extension Author
$ext_author = 'Gurkookers';

// Extension Dscription
$ext_description = 'Sample extension with required files.This Sample extensions add a string "Support extension on welcome footer".';

// Extension version support list
$EXT_SUPPORT['2.0'] = 1;
?>