<?php 

/* This file will be executed before extension installation
   You can do DATABSE related changes in this file
 */
 
?>