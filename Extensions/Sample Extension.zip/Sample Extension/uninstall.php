<?php 
/* UnInstall.php 
   This file is used in seprate to allow developers safely remove extension For example 
   to install a extension developer find and match string from original code and attach extension's code
   along with the original code, as now extension's code is in, we can find extension's code and remove it 
   without touching core code which prevents other extensions's code conflicts.
*/

// Files to extend (CASE SENSTIVE)
$extend_files = array( 

                        // File 1
						'./themes/Standards/html/home/home'.$TEXT['templates_extension'],
						
				    );
				
// Match Strings to extend (CASE SENSTIVE)
$un_extend_strings = array(

						// Array of lines to replace in File 1 
						array(
							'<span class="brz-small">&copy;</span> {$TEXT->web_name} {$TEXT->_uni-All_rights_reserved} : Support Extensions',
							'{$TEXT->_uni-Language} : {$TEXT->TEMP-active_lang} : Support extensions',
							),

				
				    );
					
// New strings 				
$un_extended_strings = array(
                        
						
						// Array of lines to find in File 1
						array(
							'<span class="brz-small">&copy;</span> {$TEXT->web_name} {$TEXT->_uni-All_rights_reserved}',
							'{$TEXT->_uni-Language} : {$TEXT->TEMP-active_lang}',
							),
						

				    );
								
// Log (Optional)
$extention_key_notes = array(

                        // Show in log while updating File 1
                        'Updating footer file  ->  Footer',
						
				    );					
			

?>